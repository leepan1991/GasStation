package com.volunteer.pojo.po;

import com.volunteer.pojo.AbstractEntity;

/**
 * Created by Administrator on 2017/9/19 0019.
 */
public class Org extends AbstractEntity {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
