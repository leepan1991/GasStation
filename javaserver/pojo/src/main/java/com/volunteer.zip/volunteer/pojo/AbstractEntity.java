package com.volunteer.pojo;

/**
 * Created by Administrator on 2017/5/17 0017.
 */
public class AbstractEntity {

    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
