package com.volunteer.pojo;

/**
 * Created by Administrator on 2017/5/17 0017.
 */
public class AbstractStringEntity {

    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
