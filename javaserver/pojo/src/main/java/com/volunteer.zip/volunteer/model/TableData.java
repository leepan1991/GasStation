package com.volunteer.model;

import java.util.List;

public class TableData {

	public List<?> data = null;

	public TableParameter page = null;
}
