package com.volunteer.pojo.dto;

import com.volunteer.pojo.po.GasBottle;

/**
 * Created by Administrator on 2017/10/1 0001.
 */
public class GasBottleDTO extends GasBottle {
    private String orderId;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}
